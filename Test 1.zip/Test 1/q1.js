function sumStrings(one,two,three)
{
    let sum = 0;
    sum = Number(one) + Number(two) + Number(three);
    return sum;
}

console.log(sumStrings("1","2","3"));