var sumStrings = function(one,two,three)
{
    return Number(one) + Number(two) + Number(three);
}

console.log(sumStrings("1","2","3"));